import express, { Request, Response } from 'express';
import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

// Configure PostgreSQL connection via environment variables.  If you have
// created a `db_config.ts` module with getConnectionString() you can import
// and use it here instead of listing the values manually.
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME || 'mydatabase',
  user: process.env.DB_USER || 'myuser',
  password: process.env.DB_PASSWORD || 'mypassword',
});

const app = express();
app.use(express.json());

/**
 * Middleware for basic admin authentication.  This is a placeholder; in a
 * production system you should implement proper authentication and
 * authorization (e.g. JWT tokens).  Here we check for a header
 * `x-user-role` equal to `admin` before allowing access to admin routes.
 */
function requireAdmin(req: Request, res: Response, next: () => void) {
  const role = req.headers['x-user-role'];
  if (role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  next();
}

// API endpoint to list all users (admin only)
app.get('/api/users', requireAdmin, async (_req: Request, res: Response) => {
  try {
    const result = await pool.query('SELECT id, name, role FROM users ORDER BY id');
    return res.json(result.rows);
  } catch (err) {
    console.error('Error fetching users:', err);
    return res.status(500).json({ error: 'Error fetching users' });
  }
});

// API endpoint to update a user role (admin only)
app.put('/api/users/:id/role', requireAdmin, async (req: Request, res: Response) => {
  const { id } = req.params;
  const { role } = req.body as { role: string };
  const validRoles = ['admin', 'manager', 'worker'];
  if (!validRoles.includes(role)) {
    return res.status(400).json({ error: 'Invalid role' });
  }
  try {
    const result = await pool.query(
      'UPDATE users SET role = $1 WHERE id = $2 RETURNING id, name, role',
      [role, id]
    );
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating user role:', err);
    return res.status(500).json({ error: 'Error updating user role' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});