import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './auth';

/**
 * Protects nested routes so that only users with the `admin` role can access them.
 * If the user is not an admin, they are redirected to the home page.
 */
export default function RequireAdmin() {
  const { user, loading } = useAuth();
  if (loading) {
    return <p>Chargement…</p>;
  }
  if (user && user.role === 'admin') {
    return <Outlet />;
  }
  return <Navigate to="/" replace />;
}