import React from 'react';

/**
 * Landing page for the application.  Replace this content with your
 * existing order modal and marketing copy.  For demonstration purposes
 * it simply displays a hero section and a call‑to‑action button.
 */
export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '4rem' }}>
      <h1>الشيلان جيت الأصلي من مختبر غولر</h1>
      <p>
        عزز طاقتك وصحتك مع الشيلان جيت النقي والغني بالمعادن. منتج طبيعي 100% أسلوبي،
        حياة صحية ونشاط.
      </p>
      <button
        onClick={() => alert('Redirect to order modal')}
        style={{ padding: '1rem 2rem', marginTop: '2rem' }}
      >
        اطلب الآن
      </button>
    </div>
  );
}