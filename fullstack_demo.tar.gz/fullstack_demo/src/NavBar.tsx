import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from './auth';

/**
 * Simple navigation bar component.  Shows links to the home page and
 * conditionally displays a link to the Role Management page if the current
 * user has the `admin` role.  Adjust the styling to fit your application.
 */
export default function NavBar() {
  const { user } = useAuth();
  return (
    <nav style={{ display: 'flex', gap: '1rem', padding: '1rem' }}>
      <Link to="/">Accueil</Link>
      {user?.role === 'admin' && <Link to="/admin/roles">Gestion des rôles</Link>}
    </nav>
  );
}