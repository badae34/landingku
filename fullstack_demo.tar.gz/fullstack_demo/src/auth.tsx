import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define the shape of the user object.  Extend this as needed.
interface User {
  id: string;
  name: string;
  role: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, loading: true });

/**
 * AuthProvider fetches the current user from the server (or local storage) and
 * makes it available to the rest of the app.  Replace the mock
 * implementation with real authentication logic.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadUser() {
      try {
        // TODO: Replace with a call to your authentication endpoint
        // For demonstration we simulate an authenticated admin user
        const mockUser: User = { id: '1', name: 'Admin User', role: 'admin' };
        await new Promise((resolve) => setTimeout(resolve, 200));
        setUser(mockUser);
      } catch (err) {
        console.error('Failed to load user', err);
        setUser(null);
      } finally {
        setLoading(false);
      }
    }
    loadUser();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}