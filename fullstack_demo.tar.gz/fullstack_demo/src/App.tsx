import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import NavBar from './NavBar';
import Home from './Home';
import RoleManagement from './RoleManagement';
import RequireAdmin from './RequireAdmin';

/**
 * Root component that defines application routes.  The routes are wrapped in
 * a BrowserRouter to enable client‑side navigation without refreshing the
 * page.  We also render a NavBar at the top of every page.
 */
export default function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route element={<RequireAdmin />}>
          <Route path="/admin/roles" element={<RoleManagement />} />
        </Route>
        {/* Catch all unknown routes and redirect to home */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}