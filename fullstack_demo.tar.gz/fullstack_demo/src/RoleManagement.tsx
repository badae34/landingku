import React, { useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  role: string;
}

const availableRoles = ['admin', 'manager', 'worker'] as const;
type Role = typeof availableRoles[number];

/**
 * Role management page.  Fetches a list of users and displays their roles
 * with the ability to change them.  Replace the mock data and updateRole
 * function with real API calls to your Express backend.
 */
export default function RoleManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchUsers() {
      try {
        setLoading(true);
        // TODO: Replace with axios.get('/api/users')
        const mockUsers: User[] = [
          { id: '1', name: 'Yassine', role: 'admin' },
          { id: '2', name: 'Sara', role: 'manager' },
          { id: '3', name: 'Omar', role: 'worker' },
        ];
        await new Promise((resolve) => setTimeout(resolve, 500));
        setUsers(mockUsers);
      } catch (err) {
        setError('Unable to load users');
      } finally {
        setLoading(false);
      }
    }
    fetchUsers();
  }, []);

  const updateRole = async (userId: string, newRole: Role) => {
    try {
      // TODO: axios.put(`/api/users/${userId}/role`, { role: newRole })
      setUsers((prev) =>
        prev.map((u) => (u.id === userId ? { ...u, role: newRole } : u))
      );
    } catch (err) {
      console.error('Failed to update role', err);
      setError('Échec de la mise à jour du rôle');
    }
  };

  if (loading) {
    return <p>Chargement…</p>;
  }
  if (error) {
    return <p style={{ color: 'red' }}>{error}</p>;
  }

  return (
    <div style={{ padding: '2rem', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Gestion des rôles</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ textAlign: 'left', borderBottom: '1px solid #ccc', padding: '0.5rem' }}>Utilisateur</th>
            <th style={{ textAlign: 'left', borderBottom: '1px solid #ccc', padding: '0.5rem' }}>Rôle</th>
            <th style={{ borderBottom: '1px solid #ccc', padding: '0.5rem' }}>Changer le rôle</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td style={{ padding: '0.5rem' }}>{user.name}</td>
              <td style={{ padding: '0.5rem' }}>{user.role}</td>
              <td style={{ padding: '0.5rem' }}>
                <select
                  value={user.role}
                  onChange={(e) => updateRole(user.id, e.target.value as Role)}
                >
                  {availableRoles.map((role) => (
                    <option key={role} value={role}>
                      {role}
                    </option>
                  ))}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}